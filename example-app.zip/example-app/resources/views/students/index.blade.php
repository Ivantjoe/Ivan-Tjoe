@extends('students.layout' )
@section( 'content' )
    <div class="container">
        <div class="row" style="margin:20px;">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Laravel 9 CRUD (Create, Read, Update, and Delete)</h2>
                    </div>
                    <div class="card-body">
                        <a href="{{ url('/student/create') }}" class="btn btn-success btn-sm" title="add new student">
                            Add New
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <tread>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Mobile</th>
                                        <th>Actions</th>
                                    </tr>
                                </tread>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Brando</td>
                                        <td>New york</td>
                                        <td>08993342156</td>

                                        <td>
                                            <a href="" title="View Student"><bottom class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</bottom></a>
                                            <a href="" title="View Student"><bottom class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</bottom></a>
                                            <a href="" title="View Student"><bottom class="btn btn-danger btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Delete</bottom></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection